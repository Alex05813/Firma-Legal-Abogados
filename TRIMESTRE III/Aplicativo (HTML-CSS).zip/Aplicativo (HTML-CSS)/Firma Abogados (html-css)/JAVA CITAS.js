document.addEventListener('DOMContentLoaded', () => {
    const monthYearElement = document.getElementById('month-year');
    const monthFooterElement = document.getElementById('month-footer');
    const yearFooterElement = document.getElementById('year-footer');
    const calendarGrid = document.getElementById('calendar-grid');
    const prevMonthButton = document.getElementById('prev-month');
    const nextMonthButton = document.getElementById('next-month');

    let currentDate = new Date();

    function renderCalendar(date) {
        const year = date.getFullYear();
        const month = date.getMonth();

        // Set month and year text
        monthFooterElement.textContent = date.toLocaleString('default', { month: 'long' }).toUpperCase();
        yearFooterElement.textContent = year;

        // Get the first day of the month and the number of days in the month
        const firstDay = new Date(year, month, 1).getDay();
        const lastDate = new Date(year, month + 1, 0).getDate();

        // Clear previous calendar grid
        calendarGrid.innerHTML = '';

        // Add empty cells for the days before the first day
        for (let i = 0; i < firstDay; i++) {
            calendarGrid.innerHTML += '<div></div>';
        }

        // Add cells for each day of the month
        for (let i = 1; i <= lastDate; i++) {
            const dayElement = document.createElement('div');
            dayElement.textContent = i;
            dayElement.classList.add('day');
            dayElement.onclick = () => {
                document.querySelectorAll('.calendar-grid .selected').forEach(el => el.classList.remove('selected'));
                dayElement.classList.add('selected');
            };
            calendarGrid.appendChild(dayElement);
        }
    }

    prevMonthButton.addEventListener('click', () => {
        currentDate.setMonth(currentDate.getMonth() - 1);
        renderCalendar(currentDate);
    });

    nextMonthButton.addEventListener('click', () => {
        currentDate.setMonth(currentDate.getMonth() + 1);
        renderCalendar(currentDate);
    });

    // Initial render
    renderCalendar(currentDate);
});
